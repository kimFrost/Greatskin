;(function(window, document, undefined) {
	var Greatskin = new namespace("Greatskin");
	Greatskin.Angular = angular.module('greatskin', []).
		config(function() { // provider-injector
			// This is an example of config block.
			// You can have as many of these as you want.
			// You can only inject Providers (not instances)
			// into the config blocks.
		}).
		run(function($rootScope) { // instance-injector
			// This is an example of a run block.
			// You can have as many of these as you want.
			// You can only inject instances (not Providers)
			// into the run blocks
			//$rootScope.findme = "test value";
		});
})(window, window.document);
;(function(window, document, undefined) {
	var Greatskin = new namespace("Greatskin");


	// Greatskin Controller
	Greatskin.Angular.controller('GreatskinCtrl', ['$scope', '$http', '$sce',  function($scope, $http, $sce) {

		// Data
		$scope.greatskinctrl = {
			options: {

			},
			states: {

			},
			css: {}
		};

		/* Scope Functions
		 ===========================*/

		$scope.greatskinctrl.trustSrc = function(src) {
			return $sce.trustAsResourceUrl(src);
		};

		/* Bindings
		 ===========================*/
		// Scope Events
		$scope.$on('GreatskinCtrlTogglePending', function(event, state) {
			//$scope.greatskinctrl.togglePending(state);
		});

		// User Events

	}]);

})(window, window.document);

;(function(window, document, undefined) {
	var Greatskin = new namespace("Greatskin");


	// Greatskin Controller
	Greatskin.Angular.controller('BasketboxCtrl', ['$scope', '$timeout', function($scope, $timeout) {

		// Data
		$scope.basketboxctrl = {
			options: {

			},
			states: {
				showbasket: false
			},
			css: {}
		};

		/* Scope Functions
		 ===========================*/
		$scope.basketboxctrl.togglebasket = function() {
			$scope.basketboxctrl.states.showbasket = !$scope.basketboxctrl.states.showbasket;
		};

		/* Bindings
		 ===========================*/
		// Scope Events

		// User Events

	}]);

})(window, window.document);

;(function(window, document, undefined) {
	var Greatskin = new namespace("Greatskin");

	// Panes Controller
	Greatskin.Angular.controller('PanesCtrl', ['$scope', '$timeout', function($scope, $timeout) {

		// Data
		$scope.panesctrl = {
			options: {

			},
			activeindex: 0,
			states: {

			},
			css: {}
		};

		/* Scope Functions
		 ===========================*/
		$scope.panesctrl.checkActive = function(id) {
			if (id != undefined) {
				if (id == $scope.panesctrl.activeindex) {
					return true;
				}
				else {
					return false;
				}
			}
		};
		$scope.panesctrl.activate = function(index) {
			if (index != undefined) {
				$scope.panesctrl.activeindex = index;
			}
		};

		/* Bindings
		 ===========================*/
		// Scope Events

		// User Events

	}]);

})(window, window.document);
